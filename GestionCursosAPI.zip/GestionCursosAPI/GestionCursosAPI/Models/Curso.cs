﻿namespace GestionCursosAPI.Models
{
    public class Curso
    {
        public int? ID { get; set; }
        public string Nombre { get; set; }
        public int Creditos { get; set; }
    }
}
